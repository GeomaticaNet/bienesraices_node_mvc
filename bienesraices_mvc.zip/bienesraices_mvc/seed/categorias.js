const categorias = [
    {
        nombre: 'Casa'
    },
    {
        nombre: 'Departamento'
    },
    {
        nombre: 'Bodega'
    },
    {
        nombre: 'Terreno'
    },
    {
        nombre: 'Cabaña'
    }
]

export default categorias